Thank you for buying the Animated Low Poly Weapons Pack!

Information:

- Blender version 2.93.2 (or higher) is required in order to open these files.

Support:

- For support and general questions please join our discord server: https://discord.gg/sqPFPe2uuU

